/* Justin Liu, jl8wf    Date:9/8/2020   Filename: List.cpp  */

#include "List.h"
#include "ListItr.h"
#include "ListNode.h"

#include <iostream>

using namespace std;

List :: List(){
  head = new ListNode();
  tail = new ListNode();
  
  head->next = tail;
  tail->previous = head;
  
  count = 0;
}

List :: List(const List& source){
  head=new ListNode();
  tail=new ListNode();
  head->next=tail;
  tail->previous=head;
  count = 0;
    // Make a deep copy of the list
  ListItr iter(source.head->next);
  while (!iter.isPastEnd()) {
     insertAtTail(iter.retrieve());
     iter.moveForward();
    }
}

List::~List(){
  makeEmpty();
  delete head;
  delete tail;
}

void List :: makeEmpty(){
  while(!isEmpty()){
    remove(this->head->next->value);
  }
  
  // ListItr l(this->first());
  // if(this->size() > 1){
  //   while(!l.isPastEnd()){
  //    l.moveForward();
  //    delete l.current->previous;
  //   }
  // }
  // else if(this->size() == 1){
  //   delete l.current;
  // }
}

List& List :: operator =(const List& source){
  if (this == &source) {
        // The two are the same list; no need to do anything
        return *this;
    }
  else {
        // Clear out anything this list contained
        // before copying over the items from the other list
        makeEmpty();

        // Make a deep copy of the list
        ListItr iter(source.head->next);
        while (!iter.isPastEnd()) {
            insertAtTail(iter.retrieve());
            iter.moveForward();
          }
    return *this;
  }
}

bool List :: isEmpty() const{
  ListItr l(head);
  if(l.current->next == tail){
    return true;
  }
  else{
    return false;
  }
}
 
ListItr List :: first(){
  ListItr l(this->head->next);
  return l;
}

ListItr List :: last(){
  ListItr l(this->tail->previous);
  return l;
}

void List :: insertAfter(int x, ListItr position){
  if(position.current->next != NULL){
    ListNode * a = new ListNode;
    a->value = x;
    a->next = position.current->next;//new node's next should be current's
    a->previous = position.current;//new node's previous should be current node

    position.current->next->previous = a;//iterator's pointer pointing at next object's previous
    position.current->next = a;//iterator's pointer's next is now new node
    count++;
  }
}

void List :: insertBefore(int x, ListItr position){
  if(position.current->previous != NULL){
    ListNode * a = new ListNode;
    a->value = x;

    //List * p = &ofSomething;
    //p = 5;
    
    a->next = position.current;//new node's next should be current's
    a->previous = position.current->previous;//new node's previous should be current node

    position.current->previous->next = a;//iterator's pointer's previous' next is now new mode
    position.current->previous = a;//iterator's pointer's previous is now new node
    count++;
  }
}

void List :: insertAtTail(int x){
  ListNode * a = new ListNode;
  ListItr itr(tail);
  a->value = x;//sets node's value
  
  a->previous = itr.current->previous;//new node's previous is now tail's previous
  a->next = tail;//new node's next is now tail
  tail->previous->next = a;//previous nod
  tail->previous = a;//tail's new previous pointer is now pointing at new node's address
  count++;
}

ListItr List :: find(int x){
  ListItr l(tail);
  while(!l.isPastBeginning()){
    l.moveBackward();
    if(l.current->value == x)
      return l;
  }
  return l;
}

void List :: remove(int x){
  ListItr found = find(x);
  if(found.current != head && found.current != tail){
    found.current->previous->next = found.current->next;//found node's previous's next should be found node's next. previous node's next is set.
    found.current->next->previous = found.current->previous;//found node's next's previous should be found node's previous
    delete found.current;//delete found node by deference?
    count--;
  }
}

int List :: size() const{
  return count;
}

void printList(List& source, bool forward){
  ListItr f = source.first();
  ListItr l = source.last();

  int count = 0;
  
  if(source.isEmpty()){
    cout << "" << endl;
  }
  
  if(forward){
    while(!f.isPastEnd()){
      count++;
      if(count == source.size()){
	cout << f.retrieve() << endl;
      }
      else{
	cout << f.retrieve() << " ";
      }
      f.moveForward();
    } 
  }
  
  else{
    while(!l.isPastBeginning()){
      count++;
      if(count == source.size()){
	cout << l.retrieve() << endl;
      }
      else{
	cout << l.retrieve() << " ";
      }
      l.moveBackward();
    }  
  }
}
