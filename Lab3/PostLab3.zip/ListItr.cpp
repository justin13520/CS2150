/* Justin Liu, jl8wf   Date:9/8/2020   Filename:ListItr.cpp */

#include "List.h"
#include "ListItr.h"
#include "ListNode.h"

ListItr :: ListItr(){
  current = NULL;
}

ListItr :: ListItr(ListNode* theNode){
  current = theNode;
}

bool ListItr :: isPastEnd() const{
  if(current != NULL && current->next == NULL){
    return true;
  } 
  return false;
}

bool ListItr :: isPastBeginning() const{
  if(current != NULL && current->previous == NULL && current->next != NULL){//if the current node's previous is not null, pass beginning
    return true;
  }
  
  return false;
}

void ListItr :: moveForward(){
  if(current->next != NULL){//if current points at dummy tail, then the next would be null
    current = current->next;
  } 
}

void ListItr :: moveBackward(){
  if(current->previous != NULL){//if current points at dummy head, then previous would be null
    current = current->previous;
  }
}

int ListItr :: retrieve() const{
  return current->value;//pointer accessing the node by dereferencing: (*current).value, where *current is the node
}
