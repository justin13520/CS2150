#include "stackCalc.h"
#include <cstdlib>
#include <iostream>

#include "ListNode.h"
#include "List.h"
#include "ListItr.h"

using namespace std;

stackCalc :: stackCalc(){
  theStack = List();
}

stackCalc :: ~stackCalc(){
  theStack.makeEmpty();
}

void stackCalc :: push(int e){
  theStack.insertAtTail(e);
}

int stackCalc :: top(){
  if(empty()){
    exit(-1);
  }
  ListItr l(theStack.last());
  return theStack.last().current->value;
}

void stackCalc :: pop(){
  if(empty()){
    exit(-1);
  }
  else{
    int e = theStack.last().current->value;
    theStack.remove(e);
  }
}

bool stackCalc :: empty(){
  if(theStack.isEmpty()){
    return true;
  }
  return false;
}

void stackCalc :: add(){
  int x = top();
  pop();
  int y = top();
  pop();
  push(y+x);
  
}

void stackCalc :: subtract(){
  int x = top();
  pop();
  int y = top();
  pop();
  push(y-x);
}

void stackCalc :: multiply(){
  int x = top();
  pop();
  int y = top();
  pop();
  push(y*x);
}

void stackCalc :: divide(){
    int x = top();
    pop();
    int y = top();
    pop();
    push(y/x);
}

void stackCalc :: negate(){
  push(top()*-1);
}

void stackCalc :: print(){
  cout << top() << endl;
}
