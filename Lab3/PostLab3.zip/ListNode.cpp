/* Justin Liu, jl8wf   Date:9/8/2020    Filename: ListNode.cpp  */

#include "ListNode.h"

ListNode :: ListNode(){
  //value = 0;
  next = NULL;
  previous = NULL;
}
