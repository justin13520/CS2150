#include <iostream>
#include "stackCalc.h"


#include "ListNode.h"
#include "List.h"
#include "ListItr.h"


using namespace std;

int main(){
  int num;
  string input;
  stackCalc calc = stackCalc();
  while(cin >> input){
    if(input == "+"){
      calc.add();
    }
    else if(input == "-"){
      calc.subtract();
    }
    else if(input == "*"){
      calc.multiply();
    }
    else if(input == "/"){
      calc.divide();
    }
    else if(input == "~"){
      calc.negate();
    }
    else{
      num = stoi(input);
      calc.push(num);
    }
  }
  calc.print();
  return 0;
}

