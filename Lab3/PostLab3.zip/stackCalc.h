#ifndef STACKCALC_H
#define STACKCALC_H

#include "ListNode.h"
#include "List.h"
#include "ListItr.h"

using namespace std;

class stackCalc{
 public:
  stackCalc();
  ~stackCalc();
  int top();
  void pop();
  void push(int e);
  bool empty();
  void add();
  void subtract();
  void multiply();
  void divide();
  void negate();
  void print();
 private:
  List theStack;
};

#endif
